/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: William
 */ 
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 * 
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * GPS_Driver.c
 *
 * Created: 17/09/2015 16:15:12
 *  Author: wmjen
 */ 


#include "Darkness_Kernel/Drivers/GPS/NMEA Architecture.h"
#include "Darkness_Kernel/kernel architecture.h"

#include "Darkness_Kernel/mailbox_library.h"
#include "Darkness_Kernel/Buffers/buffer_bytes.h"

#include "string.h"

extern struct page_manager * api_setup_pages(unsigned short int, unsigned short int, unsigned char, unsigned char, unsigned char, char);
extern void api_return_buffer(struct page_manager *, struct ipc_buffer_object *);

extern unsigned char api_post_to_buffer8(struct ipc_buffer_object *, unsigned char);


extern unsigned char api_buffer_flush8(struct ipc_buffer_object *);
extern unsigned char api_buffer_accept8(struct ipc_buffer_object *, unsigned char *);
extern struct ipc_buffer_object * api_alloc_buffer(struct page_manager *);

#define GPS_USART               (&AVR32_USART0)
#define GPS_USART_RX_PIN        AVR32_USART0_RXD_0_0_PIN
#define GPS_USART_RX_FUNCTION   AVR32_USART0_RXD_0_0_FUNCTION
#define GPS_USART_TX_PIN        AVR32_USART0_TXD_0_0_PIN
#define GPS_USART_TX_FUNCTION   AVR32_USART0_TXD_0_0_FUNCTION
#define GPS_USART_IRQ           AVR32_USART0_IRQ
#define GPS_USART_BAUDRATE      9600

static const gpio_map_t GPS_MAP =
{
	{GPS_USART_RX_PIN, GPS_USART_RX_FUNCTION},
	{GPS_USART_TX_PIN, GPS_USART_TX_FUNCTION}
};

extern struct task_ctrl_obj * gps;
struct identifier * gps_id;

struct page_manager * NMEA_Buffers = NULL;
struct ipc_buffer_object * working_buffer = NULL;

struct ipc_mailbox_object * NMEA_mailbox = NULL;

/*
Use this attribute on the ARM, AVR, CR16, Epiphany, M32C, M32R/D, m68k, MeP, MIPS, RL78, RX and
Xstormy16 ports to indicate that the specified function is an interrupt handler. The compiler
generates function entry and exit sequences suitable for use in an interrupt handler when this
attribute is present. With Epiphany targets it may also generate a special section with code to
initialize the interrupt vector table.  Note, interrupt handlers for the Blackfin, H8/300, H8/300H,
H8S, MicroBlaze, and SH processors can be specified via the interrupt_handler attribute.

Note, on the AVR, the hardware globally disables interrupts when an interrupt is executed. The first
instruction of an interrupt handler declared with this attribute is a SEI instruction to re-enable
interrupts. See also the signal function attribute that does not insert a SEI instruction. If both
signal and interrupt are specified for the same function, signal is silently ignored.
*/
static void NMEA_Bridge(int argument){
	api_post_to_mailbox(NMEA_mailbox, to_anyone, (void *)argument);
}

static void usart_int_handler(void){
	
	#define DropCharacters 9
	
	static unsigned char state_machine = DropCharacters;
	static int crc_offset = 0; 
	
	int rx_char = 0, usart_error = 0;
		
	// In the code line below, the interrupt priority level does not need to be
	// explicitly masked as it is already because we are within the interrupt
	// handler.
	// The USART Rx interrupt flag is cleared by side effect when reading the
	// received character.
	// Waiting until the interrupt has actually been cleared is here useless as
	// the call to usart_write_char will take enough time for this before the
	// interrupt handler is leaved and the interrupt priority level is unmasked by
	// the CPU.
	usart_error = usart_read_char(GPS_USART, &rx_char);
		
	
	if(usart_error == USART_SUCCESS)
	{
			
		// Process NMEA Packet Position using start character $ and end character *
		switch (rx_char){
			case '$':	api_buffer_flush8(working_buffer);
						state_machine = 1;
			break;
			
			case '*':	if(state_machine == 1) { state_machine = 2; crc_offset = 0; }
			break;
			
			default:
			break;
		}
				

		// Obtain NMEA packet - state machine
		switch(state_machine){
			
			case 1: api_post_to_buffer8(working_buffer, (unsigned char)rx_char);
			break;
			
			case 2: 
					api_post_to_buffer8(working_buffer, (unsigned char)rx_char);
			
					if(++crc_offset == 3){
						api_invoke(gps_id, (int)working_buffer); working_buffer = api_alloc_buffer(NMEA_Buffers); state_machine = DropCharacters;
					}
			break;
			
			default:
			break;
		}
	}
	// Read character received here now in case it is overwritten later when parsing
	// Note, this is a heuristic error, probably due to the slow baud rate of the gps
	// No attempt to reset the baud rate has been made.
	else{
		state_machine = DropCharacters; GPS_USART->cr |= AVR32_USART_CR_RSTSTA_MASK;
	}
}

static unsigned char test_check_sum(unsigned char * NMEA_telegram_local){ 
 
 /*
  * The checksum at the end of each sentence is the XOR of all of the bytes in the sentence, 
  * excluding the initial dollar sign. The following C code generates a checksum for the 
  * string entered as "my_string" and prints it to the output stream. In the example, a sentence 
  * from the sample file is used.
  */
	unsigned char local_crc = 0;
 
	char crc_string[2];
	char calculated_crc[2] = {0};
 
	//$[[GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W]]*6A
	
	// Calculate Header checksum - skip $  
	NMEA_telegram_local++;
 
 
	// Calculate Payload checksum including marker *
	while(* NMEA_telegram_local != '*'){
		local_crc ^= * NMEA_telegram_local++;  // ,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W
	}
	
	int i = 1;
    unsigned int quotient = (int)local_crc; int interger; char ascii;

     while(quotient != 0){
   
		interger = quotient % 16;
     
		//To convert integer into ascii characters to compare with telegram 
		if( interger < 10)
			ascii = interger + 48; // Numeric Value to ASCII
      
		else
			ascii = interger + 55; // HEX Character to ASCII
      

		calculated_crc[i--]= ascii;
		quotient = quotient >> 4;
     }
 
 
	NMEA_telegram_local++; // Skip payload marker, '*'
 
	crc_string[0] = * NMEA_telegram_local++; // Obtain ASCII check sum from telegram
	crc_string[1] = * NMEA_telegram_local;

	// Validate check sum header with local correlated check sum, return true if checksum is correct
	if((calculated_crc[0] == crc_string[0]) && (calculated_crc[1] == crc_string[1])){
		// CheckSum Correct, return true
		return(true);
	}
	else{
		// CheckSum Failure, return false
		return(false);
	}
}


static void system_runtime_application(void){ 
	
	static unsigned int seconds = 0, minutes = 0, hours = 0, days = 0;
	
	
	seconds++; 
	kernel_core.system_runtime[11] = (seconds % 10) + 0x30;
	kernel_core.system_runtime[10] = (seconds / 10) + 0x30;
	
	if(seconds == 60){
		
		seconds = 0; minutes++;
		
		kernel_core.system_runtime[11] = '0';;
		kernel_core.system_runtime[10] = '0';
		
		kernel_core.system_runtime[8] = (minutes % 10) + 0x30;
		kernel_core.system_runtime[7] = (minutes / 10) + 0x30;
		
		
		if(minutes == 60){
			
			minutes = 0; 
			
			kernel_core.system_runtime[8] = '0';
			kernel_core.system_runtime[7] = '0';
			
			hours++;
			kernel_core.system_runtime[5] = (hours % 10) + 0x30;
			kernel_core.system_runtime[4] = (hours / 10) + 0x30;
			
			if(hours == 24){
				
				hours = 0; 
				
				kernel_core.system_runtime[5] = '0';
				kernel_core.system_runtime[4] = '0';
				
				days++;
				kernel_core.system_runtime[2] = (days % 10)  + 0x30;
				kernel_core.system_runtime[1] = (days / 10)  + 0x30;
				kernel_core.system_runtime[0] = (days / 100) + 0x30;
			}
		}
	}
}

static unsigned char ScanTelegramPotocol(volatile unsigned char * NMEA_packet, unsigned char target){
	int k = 0, j = 0;
	
	// Ensure we are at the start of the Telegram
	NMEA_packet = &NMEA_packet[0];
	
	// Scan Telegram
	while(j != target) { if(*NMEA_packet++ == ','){j++; } k++; }	
		return(k);
}

void copernicus_gps(void);
void copernicus_gps(void){
	
	// USART options.
	usart_options_t USART_OPTIONS =
	{
	.baudrate     = GPS_USART_BAUDRATE,
	.charlength   = 8,
	.paritytype   = USART_NO_PARITY,
	.stopbits     = USART_1_STOPBIT,
	.channelmode  = USART_NORMAL_CHMODE
	};
	
		
	struct ipc_buffer_object * processing_buffer;
	
	gps_id = register_deferal(NMEA_Bridge);
	
	// Configure Task Resources
	NMEA_mailbox	= api_create_mailbox();
	
	NMEA_Buffers	= api_setup_pages(24, 200, BYTE, 0, 0, false);
	working_buffer	= api_alloc_buffer(NMEA_Buffers);
	
	// Assign Local Buffer and clear it's contents
	unsigned char NMEA_telegram[100] = {0};
	
	unsigned char protocol_status;
	
	enter_critical_section();
	
	// Assign GPIO to USART.
	gpio_enable_module(GPS_MAP, sizeof(GPS_MAP) / sizeof(GPS_MAP[0]));
	
	// Enable USART Rx interrupt.
	INTC_register_interrupt((__int_handler)&usart_int_handler, GPS_USART_IRQ, AVR32_INTC_INT2);

	// Initialize USART in RS232 mode.
	usart_init_rs232(GPS_USART, &USART_OPTIONS, 66000000);
	
	GPS_USART->ier = AVR32_USART_IER_RXRDY_MASK;
	
	leave_critical_section();
	
	
	/****************************************** NMEA TASK PARSER *******************************************/
	do{ 
		
		TelegramError:
		
		asm ("nop");
		int NMEA_state_maching = FAILURE, SateliteCount = 0;
		
		// receive NMEA packet from interrupt
		processing_buffer = api_recieve_mail(NMEA_mailbox, from_IRQ, 0);
		
		int buffer_position = 0;
		
		// Obtain telegram packet and buffer into temporary buffer for processing
		do{
			NMEA_telegram[buffer_position++] = api_buffer_accept8(processing_buffer, &protocol_status);
		}while(protocol_status == SUCCESSFUL);
		
		// Return NMEA Buffer to Buffer Pool 
		api_return_buffer(NMEA_Buffers, processing_buffer);
		
		
		// Process check sum and continue if correct
		if(test_check_sum(&NMEA_telegram[0])){
			
			if(memcmp((unsigned char *)NMEA_telegram,	"$GPRMC", 6) == 0){
				NMEA_state_maching = 1; system_runtime_application();
			}
			else if(memcmp((unsigned char *)NMEA_telegram, "$GPVTG", 6) == 0){
				NMEA_state_maching = 2;
			}
			else if(memcmp((unsigned char *)NMEA_telegram, "$GPGGA", 6) == 0){
				NMEA_state_maching = 3;
			}
			else if(memcmp((unsigned char *)NMEA_telegram, "$GPGSA", 6) == 0){
				NMEA_state_maching = 4;
			}
			else if(memcmp((unsigned char *)NMEA_telegram, "$GPGSV", 6) == 0){
				SateliteCount = 0; NMEA_state_maching = 5;
			}
			else if(memcmp((unsigned char *)NMEA_telegram, "$GPGLL", 6) == 0){
				NMEA_state_maching = 6;
			}
			else{
				NMEA_state_maching = 7; goto TelegramError; 
			}
			
			
			
			
			
			
			unsigned char NMEA_offset = 0;
			switch(NMEA_state_maching){
				
				case FAILURE:		// FAILURE
				break;
				
				//$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A
				case 1:
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 1);
					NMEA_GPRMC.UTC_Time[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Time[1] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Time[2] = ':';
				
					NMEA_GPRMC.UTC_Time[3] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Time[4] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Time[5] = ':';
				
					NMEA_GPRMC.UTC_Time[6] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Time[7] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Time[8] = '\0';
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 2);
					NMEA_GPRMC.Status[0] = NMEA_telegram[NMEA_offset];
					
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 3);
					for(int index = 0; index <= 9; index++){
						NMEA_GPRMC.Latitude[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 5);
					for(int index = 0; index <= 10; index++){
						NMEA_GPRMC.Longitude[index] = NMEA_telegram[NMEA_offset++];
					}
				
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 7);
					for(int index = 0; index <= 4; index++){
						NMEA_GPRMC.Speed[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 8);
					for(int index = 0; index <= 4; index++){
						NMEA_GPRMC.Track[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 9);
					NMEA_GPRMC.UTC_Date[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Date[1] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Date[2] = ':';
				
					NMEA_GPRMC.UTC_Date[3] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Date[4] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Date[5] = ':';
					
					NMEA_GPRMC.UTC_Date[6] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Date[7] = NMEA_telegram[NMEA_offset++];
					NMEA_GPRMC.UTC_Date[8] = '\0';
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 10);
					for(int index = 0; index <= 6; index++){
						NMEA_GPRMC.Magnetic_Variation[index] = NMEA_telegram[NMEA_offset++];
					}
				break;

				// $GPVTG,054.7,T,034.4,M,005.5,N,010.2,K*48
				case 2:
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 1);
					for(int index = 0; index <= 6; index++){
						NMEA_GPVTG.True_track[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 3);
					for(int index = 0; index <= 6; index++){
						NMEA_GPVTG.Magnetic_track[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 5);
					for(int index = 0; index <= 6; index++){
						NMEA_GPVTG.Ground_speed_knots[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 7);
					for(int index = 0; index <= 6; index++){
						NMEA_GPVTG.Ground_speed_Kilometers[index] = NMEA_telegram[NMEA_offset++];
					}
				break;
				
				// $GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47
				case 3:	
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 1);
					for(int index = 0; index <= 5; index++){
						NMEA_GPGGA.Fix_taken_at[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 2);
					for(int index = 0; index <= 10; index++){
						NMEA_GPGGA.Latitude[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 4);
					for(int index = 0; index <= 11; index++){
						NMEA_GPGGA.Longitude[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 6);
					NMEA_GPGGA.Fix_quality[0] = NMEA_telegram[NMEA_offset++];
					
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 7);
					NMEA_GPGGA.Number_of_satellites[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGGA.Number_of_satellites[1] = NMEA_telegram[NMEA_offset++];
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 8);
					NMEA_GPGGA.Horizontal_dilution[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGGA.Horizontal_dilution[1] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGGA.Horizontal_dilution[2] = NMEA_telegram[NMEA_offset++];
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 9);
					for(int index = 0; index <= 6; index++){
						NMEA_GPGGA.Altitude[index] = NMEA_telegram[NMEA_offset++];
					}
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 11);
					for(int index = 0; index <= 5; index++){
						NMEA_GPGGA.Height_of_geoid[index] = NMEA_telegram[NMEA_offset++];
					}		
				break;
				
				// $GPGSA,A,3,04,05,,09,12,,,24,,,,,2.5,1.3,2.1*39
				case 4:	NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 1);
				NMEA_GPGSA.Auto_selection[0] = NMEA_telegram[NMEA_offset++];
				
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 2);
				NMEA_GPGSA.Fix[0] = NMEA_telegram[NMEA_offset++];
				
				
				
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 3);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites1[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites1[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites1[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 4);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites2[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites2[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites2[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 5);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites3[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites3[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites3[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 6);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites4[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites4[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites4[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 7);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites5[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites5[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites5[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 8);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites6[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites6[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites6[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 9);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites7[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites7[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites7[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 10);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites8[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites8[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites8[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 11);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites9[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites9[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites9[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 12);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites10[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites10[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites10[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 13);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites11[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites11[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites11[1] = NMEA_telegram[NMEA_offset++];
				}
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 14);
				if(NMEA_telegram[NMEA_offset] == ','){
					NMEA_GPGSA.PRNs_of_satellites12[0] = '\0';
				}
				else{
					NMEA_GPGSA.PRNs_of_satellites12[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSA.PRNs_of_satellites12[1] = NMEA_telegram[NMEA_offset++];
				}
				
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 15);
				NMEA_GPGSA.PDOP[0] = NMEA_telegram[NMEA_offset++];
				NMEA_GPGSA.PDOP[1] = NMEA_telegram[NMEA_offset++];
				NMEA_GPGSA.PDOP[2] = NMEA_telegram[NMEA_offset++];
				
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 16);
				NMEA_GPGSA.HDOP[0] = NMEA_telegram[NMEA_offset++];
				NMEA_GPGSA.HDOP[1] = NMEA_telegram[NMEA_offset++];
				NMEA_GPGSA.HDOP[2] = NMEA_telegram[NMEA_offset++];
				
				NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 17);
				NMEA_GPGSA.VDOP[0] = NMEA_telegram[NMEA_offset++];
				NMEA_GPGSA.VDOP[1] = NMEA_telegram[NMEA_offset++];
				NMEA_GPGSA.VDOP[2] = NMEA_telegram[NMEA_offset++];
				break;
				
				// $GPGSV,2,1,08,01,40,083,46,02,17,308,41,12,07,344,39,14,22,228,45*75
				case 5:	
					
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 2);
					int page = (NMEA_telegram[NMEA_offset] - 0x30) - 1;
					
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 3);
					int satellite = (NMEA_telegram[NMEA_offset++] - 0x30) * 10;
					satellite += (NMEA_telegram[NMEA_offset++] - 0x30);
					
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 1);
					NMEA_GPGSV[page].Number_of_sentences[0] = NMEA_telegram[NMEA_offset++];
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 2);
					NMEA_GPGSV[page].sentence[0] = NMEA_telegram[NMEA_offset++];
				
					NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 3);
					NMEA_GPGSV[page].Number_of_satellites[0] = NMEA_telegram[NMEA_offset++];
					NMEA_GPGSV[page].Number_of_satellites[1] = NMEA_telegram[NMEA_offset++];
				
				
					for(int index = 0, j = 4; index < 4; index++, j += 4){
						
						if(SateliteCount++ == satellite){
							break;
						}
						
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, j);
						NMEA_GPGSV[page].Satellite_PRN_number[index][0] = NMEA_telegram[NMEA_offset++];
						NMEA_GPGSV[page].Satellite_PRN_number[index][1] = NMEA_telegram[NMEA_offset++];
					
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, j + 1);
						NMEA_GPGSV[page].Elevation[index][0] = NMEA_telegram[NMEA_offset++];
						NMEA_GPGSV[page].Elevation[index][1] = NMEA_telegram[NMEA_offset++];
					
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, j + 2);
						NMEA_GPGSV[page].Azimuth[index][0] = NMEA_telegram[NMEA_offset++];
						NMEA_GPGSV[page].Azimuth[index][1] = NMEA_telegram[NMEA_offset++];
						NMEA_GPGSV[page].Azimuth[index][2] = NMEA_telegram[NMEA_offset++];
					
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, j + 3);
						NMEA_GPGSV[page].SNR[index][0] = NMEA_telegram[NMEA_offset++];
						NMEA_GPGSV[page].SNR[index][1] = NMEA_telegram[NMEA_offset++];
					}
					break;
				
				// $GPGLL,4916.45,N,12311.12,W,225444,A,*1D
				case 6:	
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 1);
						for(int index = 0; index <= 8; index++){
							NMEA_GPGLL.Latitude[index] = NMEA_telegram[NMEA_offset++];
						}
						
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 3);
						for(int index = 0; index <= 9; index++){
							NMEA_GPGLL.Longitude[index] = NMEA_telegram[NMEA_offset++];
						}
						
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 5);
						for(int index = 0; index <= 5; index++){
							NMEA_GPGLL.Fix_taken[index] = NMEA_telegram[NMEA_offset++];
						}
						
						NMEA_offset = ScanTelegramPotocol(NMEA_telegram, 6);
						NMEA_GPGLL.Data_Status[0] = NMEA_telegram[NMEA_offset++];
				break;
				
				default:
				break;
			}
		}
	} while (true);
}

